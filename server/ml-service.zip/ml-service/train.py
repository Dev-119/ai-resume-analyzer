import numpy as np
from sklearn.ensemble import RandomForestRegressor
import joblib

X = [
    [1,1,1,0,0],  # strong resume
    [1,1,0,0,0],
    [1,0,0,0,0],
    [1,1,1,1,1],
    [0,0,0,0,0]
]

y = [85, 70, 50, 95, 20]

model = RandomForestRegressor()
model.fit(X, y)

joblib.dump(model, "model.pkl")
print("Model trained")