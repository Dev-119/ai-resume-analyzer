const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
const Resume = require("../models/resume");

exports.analyzeResume = async (req, res) => {
  try {
    const userId = req.user.userId;

    const form = new FormData();
    form.append("resume", fs.createReadStream(req.file.path));
    form.append("jd_skills", "java,react,node,docker,aws");

    const mlResponse = await axios.post(
      "http://localhost:8000/predict",
      form,
      { headers: form.getHeaders() }
    );

    const result = {
      score: mlResponse.data.score, // ✅ ONLY THIS
      skills: mlResponse.data.skills,
      matched_skills: mlResponse.data.matched_skills,
      missing_skills: mlResponse.data.missing_skills,
      jobs: ["Frontend Dev", "Backend Dev"]
    };

    await new Resume({ userId, ...result }).save();

    res.json(result);

  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: "ML integration failed" });
  }
};